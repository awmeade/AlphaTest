
AlphaTest 1.0

Gary J. Lautenschlager   &   Adam W. Meade
University of Georgia    North Carolina State University

AlphaTest 1.0 is a Windows-based program designed to allow user-friendly tests of differences in estimated coefficients alpha.  

There are two types of alpha tests that can be conducted.  The first is for independent samples, the second for dependent samples.

Independent samples are different groups.  This option is used when correlations between tests are not available.  This option is appropriate for cases in which different people take the same test or when different people take different tests.

Dependent samples refer to cases in which the same people take different tests (or the same test twice).  In this case, you will need to input the correlations among the tests along with information related to the alpha values.

The program interface should be self-explanatory.  You will be prompted to input correlations between tests only if you choose the Dependent Samples option.



Technical information:
This program implements the procedure published in Feldt, Woodruff and Salih (1987):

Feldt, L. S., Woodruff, D. J., & Salih, F. A. (1987). Statistical inference for coefficient alpha. Applied Psychological Measurement, 11, 93-103.


An Example:

A researcher is interested in knowing if a scale developed on teenagers to measure a child's self-concept could be used with much younger children.  The measure has a total of 20 items.  The researcher administers the self-concept measure to groups of children in 3rd grade, 6th grade and 9th grade.  

There are 64 children in the 3rd grade sample and their value of alpha = .72.  There are 87 children in 6th grade and their alpha = .81.  There are 101 children in 9th grade and their alpha = .87.  Is there a difference in the alpha reliabilities for these children?  This is an example of an independent groups.

The following output was given by the program for this analysis:
----------------------begin program output--------------------

   Alpha Test for Windows, V. 1.0
                by
Gary J. Lautenschlager & Adam W. Meade

Output File Name: C:\output.out

INPUT:

Type of Analysis    : Independent Samples
# Alphas to compare : 3

Alpha Data: 
Alpha	# Items	Sample Size
.72	20	64
.81	20	87
.87	20	101

OUTPUT:

Chi-Square:  10.8908
df        :  2
p.        :  0.0043

----------------------end program output--------------------

As you can see, the null hypothesis of equal alpha internal consistency estimates is rejected.  The input is also reproduced in the output file.

Follow-up pair-wise tests may be of interest to the researcher, but are not automatically performed.  Users must separately test any desired more specific comparison(s). We recommend that researchers use a Bonferroni correction in follow-up tests in order to control Type I error.


For example, comparing only the first 2 groups from the previous example produces:

----------------------begin program output--------------------

    Alpha Test for Windows, V. 1.0

                by

Gary J. Lautenschlager & Adam W. Meade


Output File Name: C:\Comparison1.out


INPUT:

Type of Analysis    : Independent Samples
# Alphas to compare : 2

Alpha Data: 
Alpha	# Items	Sample Size
.72	20	64
.81	20	87



OUTPUT:

Chi-Square:  2.5024
df        :  1
p.        :  0.1137


----------------------end program output--------------------

We hope you find the program useful and we ask that you cite the program when used in your work.

Special thanks to Lee Wilkinson for help with the algorithm used to estimate the probability of chi-square values.

